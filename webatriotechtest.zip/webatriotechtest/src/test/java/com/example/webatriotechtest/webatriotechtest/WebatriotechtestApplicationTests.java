package com.example.webatriotechtest.webatriotechtest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WebatriotechtestApplicationTests {

	@Test
	void contextLoads() {
	}

}
