package com.example.webatriotechtest.webatriotechtest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WebatriotechtestApplication {

	public static void main(String[] args) {
		SpringApplication.run(WebatriotechtestApplication.class, args);
	}

}
